from django.apps import AppConfig


class BgtasksConfig(AppConfig):
    name = 'bgtasks'
